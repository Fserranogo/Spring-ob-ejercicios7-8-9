package com.example.ejercicios456;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicios456ApplicationTests {

	@Test
	void contextLoads() {
	}

}
